#include<stdio.h>
int main(void){
    int h;
    do{
        printf("enter the height:");
        scanf("%d",&h);
    }
    while ( h<0 );
    for (int i =1; i<=h; i++)
    {
        for (int s= 0; s<=h-i-1; s++){
            printf(" ");
        }
        for(int j =1; j<=i; j++){
            printf("#");
        }
    printf("\n");
    }

}
