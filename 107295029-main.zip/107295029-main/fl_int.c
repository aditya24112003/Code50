#include<stdio.h>
int main (void)
{
    float x;
    printf("enter a floating number:");
    scanf("%f", &x);
    int y;
    y=x;
    float z = x-y;
    printf("the fractional part is:%f", z);
}
