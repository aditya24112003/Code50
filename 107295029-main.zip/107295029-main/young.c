#include<stdio.h>

int main(void) {
    int r_age, s_age, a_age;

    printf("Enter Ram's age: ");
    scanf("%d", &r_age);

    printf("Enter Shyam's age: ");
    scanf("%d", &s_age);

    printf("Enter Ajay's age: ");
    scanf("%d", &a_age);

    if (r_age < s_age && r_age < a_age) {
        printf("Ram is the youngest.");
    }
    else if (s_age < r_age && s_age < a_age) {
        printf("Shyam is the youngest.");
    }
    else {
        printf("Ajay is the youngest.");
    }


}
