#include<stdio.h>
int main(void)
{   int n;
    printf("enter a number:");
    scanf("%d", &n);
    for (int i =1; i<=n; i=i+1){
    printf("hello aditya\n");
}

}
