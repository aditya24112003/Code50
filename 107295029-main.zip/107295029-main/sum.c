#include <stdio.h>
int main(void)
{
    int x ;
    printf("enter a number:");
    scanf("%d" ,&x);
    int y ;
    printf("enter a number:");
    scanf("%d" , &y);
    printf("the sum of given numbers is : %d", x+y);
}
