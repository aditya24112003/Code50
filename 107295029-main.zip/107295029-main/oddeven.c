#include <stdio.h>
int main(void)
{
    int x ;
    printf("enter a number:");
    scanf("%d",&x);
    if(x%2==0){
        printf("number is even");
    }
    else{
        printf("number is odd");
    }
}
