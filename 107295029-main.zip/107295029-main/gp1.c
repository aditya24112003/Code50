#include<stdio.h>
int main (void)
{
    for (int i =100; i>= 0; i=i-3 ){
        printf("%d\n",i);
    }
}
