#include<stdio.h>
int main(void){
    int n;
    printf("enter the number:");
    scanf("%d", &n);
    int count = 0;
    while(n!=0){
        n= n/10;
        count=count+1;
    }
    printf("Count of digits is %d:" , count );
}
