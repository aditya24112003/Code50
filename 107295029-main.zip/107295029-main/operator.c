#include <stdio.h>
int main(void)
{
    int a , b ;
    printf("enter dividend:");
    scanf("%d", &a);
    printf("enter divisor:");
    scanf("%d", &b);
    printf("the remainder comes out :%d", a%b);
}
