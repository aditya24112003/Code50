#include<stdio.h>
int main (void)
{
    printf("hello world\n");
    int x;
    x = 3;
    printf("%d\n", x);
}

