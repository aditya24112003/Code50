#include <stdio.h>
int main (void)
{
    char x = 'h';
    printf("the character is :%c" , x);
}
