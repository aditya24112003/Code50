#include<stdio.h>
void greet(){
    printf("hello , good morning\n");
    printf(" how are you?\n");
}
int main(void){
    greet();
}
