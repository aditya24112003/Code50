#include<stdio.h>
int main(void){
    int i =1;
    while(i<=10){
        printf("%d\n",i);
        i++;
    }

}
