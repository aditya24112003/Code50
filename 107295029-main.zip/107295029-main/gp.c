// #include<stdio.h>
// int main(void){
//     int n ;
//     printf("enter the number:");
//     scanf("%d", &n);
//     int a =1;
//     for (int i=1; i<=n; i=i+1){

//         printf("%d\n", a);
//         a= a*2;
//     }
// }
#include<stdio.h>
int main(void){
    int n ;
    printf("enter the number:");
    scanf("%d", &n);
    float a =100;
    for (int i=1; i<=n; i=i+1){

        printf("%f\n", a);
        a= a/2;
    }
}
