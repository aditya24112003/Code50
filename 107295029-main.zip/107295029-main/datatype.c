// // area of a ci
// #include <stdio.h>
// int main(void)
// {
//     int r = 4;
//     float A = 3.14*r*r;
//     printf("the area of a circle is: %f" , A);
// }
//percenatge
#include <stdio.h>
int main (void)
{
    float a ,b,c,d,e;
    a = 36;
    b = 40;
    c = 32;
    d = 39;
    e = (a+b+c+d)/(160)*(100);
    printf("the percenatge is : %f" , e);
}
