#include<stdio.h>
void meow(void)
{
    printf("meow\n");
}
int main (void)
{
    for(int i = 0; i <5; i++)
    {
        meow();
    }
}
