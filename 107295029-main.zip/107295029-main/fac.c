#include<stdio.h>
int main(void){
    int m;
    printf("enter the number:");
    scanf("%d",&m);
    for(int i =m-1; i>=1; i--){
        printf("%d", m*i);
    }


}
