#include<stdio.h>
int main(void)
{
    int a,b,c, d;
    printf("enter length of recatangle:");
    scanf("%d",&a);
    printf("enter breadth of rectangle:" );
    scanf("%d",&b);
    c = a*b;
    d = (a+b)*2;
    printf("%d\n",c);
    printf("%d\n",d);
    if(c>d){
        printf("area of rectangle is greater than its perimeter");

    }
    if (c<d){
        printf("area of rectangle is less tham its perimeter");
    }
    if (c=k=d){
        printf("area of rectanngle is equal to its perimeter");
    }
}
