#include<stdio.h>
int main(void){
    int a;
    printf("enter the number:");
    scanf("%d", &a);
    if(a>99 && a<1000){
        printf("it is a 3 digit number");
    }
    else{
        printf("it is not a 3 digit number");
    }

}
