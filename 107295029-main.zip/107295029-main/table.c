 #include<stdio.h>
 int main(void)
 {
     for(int i =1; i<=10;i=i+1){
         printf("%d\n", 19*i );
     }
 }
 #include<stdio.h>
 int main(void)
 {
     for(int i =19; i<=190;i=i+19){
         printf("%d\n", i );
     }
 }

}
