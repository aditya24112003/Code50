// // area of a ci
#include <stdio.h>
int main(void)
{
    float r;
    printf("enter radius:");
    scanf("%f",&r);
    float A = 3.14*r*r;
    printf("the area of a circle is: %f" , A);
}
