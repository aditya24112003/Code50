#include<stdio.h>
int main(void){
    int n;
    printf("enter a number:");
    scanf("%d", &n);
    int hf =1;
    for(int i =1; i<=n-1; i++){
        if (n%i==0) hf=i;

    }
    printf("highest factor is %d:", hf);

}
